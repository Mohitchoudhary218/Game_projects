#include<iostream>
#include<GL/glut.h>

using namespace std;

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0.0,0.0,0.0);
    glEnable(GL_LINE_STIPPLE);
        glLineWidth(5.0);
        glLineStipple(1, 0x124F);
        glBegin(GL_LINES);
            glVertex2f(50.0,100.0);
            glVertex2f(150.0,100.0);
        glEnd();
        glLineStipple(1, 0xF0F0);
        glBegin(GL_LINES);
            glVertex2f(150.0,100.0);
            glVertex2f(250.0,100.0);
        glEnd();
        glLineWidth(5.0);
        glLineStipple(1, 0x00FF);
        glBegin(GL_LINES);
            glVertex2f(50.0,100.0);
            glVertex2f(150.0,150.0);
        glEnd();
        glLineStipple(1, 0xF0F0);
        glBegin(GL_LINES);
            glVertex2f(150.0,150.0);
            glVertex2f(250.0,150.0);
        glEnd();
        glLineStipple(2,0xcc11);
        glBegin(GL_LINES);
            glVertex2f(250.0,150.0);
            glVertex2f(300.0,200.0);
        glEnd();
        glLineStipple(2,0x1122);
        glBegin(GL_LINES);
            glVertex2f(300.0,200.0);
            glVertex2f(250.0,100.0);
        glEnd();
    glDisable(GL_LINE_STIPPLE);
    glFlush();
}

void starting()
{
    GLclampf c = 1.0f;
    glClearColor(c,c,c,c);
    glShadeModel(GL_FLAT);
}

void reshape(int y, int x)
{
    glViewport(0,0,(GLsizei) y,(GLsizei) x);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0.0,(GLdouble) y,0.0,(GLdouble) x);
}

int main(int argc, char** argv)
{
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowPosition(100,100);
    glutInitWindowSize(500,500);
    glutCreateWindow("VECTOR_GEOMETRY");
    starting();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMainLoop();

    return 0;
}






